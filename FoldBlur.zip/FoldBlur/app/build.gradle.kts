plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kyn.foldblur"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kyn.foldblur"
        minSdk = 31          // 창 뒤 블러(blurBehindRadius)는 Android 12+
        targetSdk = 35
        versionCode = 2
        versionName = "0.2"
    }

    // 고정 디버그 키: 다음 빌드부터는 삭제 없이 덮어쓰기 설치 가능
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
