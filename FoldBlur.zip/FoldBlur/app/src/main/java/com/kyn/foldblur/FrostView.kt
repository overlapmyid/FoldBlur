package com.kyn.foldblur

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.view.View
import kotlin.random.Random

/**
 * 습기 찬 유리 / 서리 유리 느낌을 그리는 뷰.
 * 삼성은 다른 앱 화면을 실시간으로 흐리게 하는 시스템 블러를 서드파티 앱에 잘 열어주지 않기 때문에,
 *  1) 뿌연 우윳빛 막
 *  2) 크게 번진 얼룩(습기가 고르지 않게 맺힌 느낌)
 *  3) 미세 입자(서리 유리 질감)
 * 세 겹으로 "흐려 보이는" 착시를 만든다. 시스템 블러가 되는 기기면 그 위에 같이 얹힌다.
 */
class FrostView(context: Context) : View(context) {

    private var cfg: EffectConfig? = null

    private val dimPaint = Paint()
    private val fogPaint = Paint()
    private val blotchPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val grainPaint = Paint()

    private val blotchBitmap: Bitmap = makeBlotches(40, 64)
    private val grainBitmap: Bitmap = makeGrain(160)
    private val blotchMatrix = Matrix()

    init {
        grainPaint.shader = BitmapShader(grainBitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    fun update(c: EffectConfig) {
        cfg = c
        dimPaint.color = Color.argb(pct(c.maxDim), 0, 0, 0)
        val (r, g, b) = if (c.darkFog) Triple(40, 44, 52) else Triple(236, 240, 245)
        fogPaint.color = Color.argb(pct(c.fog), r, g, b)
        blotchPaint.alpha = (c.fog / 100f * 200).toInt().coerceIn(0, 255)
        grainPaint.alpha = (c.grain / 100f * 110).toInt().coerceIn(0, 255)
        invalidate()
    }

    private fun pct(v: Int) = (v.coerceIn(0, 100) / 100f * 255).toInt()

    override fun onDraw(canvas: Canvas) {
        val c = cfg ?: return
        if (c.maxDim > 0) canvas.drawPaint(dimPaint)
        if (c.fog > 0) {
            canvas.drawPaint(fogPaint)
            // 작은 랜덤 비트맵을 화면 크기로 부드럽게 확대 → 불규칙한 습기 얼룩
            blotchMatrix.setScale(
                width / blotchBitmap.width.toFloat(),
                height / blotchBitmap.height.toFloat(),
            )
            canvas.drawBitmap(blotchBitmap, blotchMatrix, blotchPaint)
        }
        if (c.grain > 0) canvas.drawPaint(grainPaint)
    }

    private fun makeBlotches(w: Int, h: Int): Bitmap {
        val rnd = Random(7)
        val px = IntArray(w * h) {
            val a = rnd.nextInt(0, 150)
            val v = rnd.nextInt(215, 256)
            Color.argb(a, v, v, v)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun makeGrain(size: Int): Bitmap {
        val rnd = Random(11)
        val px = IntArray(size * size) {
            val v = if (rnd.nextBoolean()) 255 else 0
            Color.argb(rnd.nextInt(0, 90), v, v, v)
        }
        return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
    }
}
