package com.kyn.foldblur

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity(), SensorEventListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var sensorManager: SensorManager
    private var hinge: Sensor? = null

    private lateinit var statusText: TextView
    private lateinit var angleText: TextView
    private lateinit var switchText: TextView
    private lateinit var toggleButton: Button
    private lateinit var motionSwitch: Switch
    private val sliders = mutableMapOf<String, SeekBar>()
    private val handler = Handler(Looper.getMainLooper())

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.LAST_SWITCH_ANGLE) refreshSwitchAngle()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        sensorManager = getSystemService(SensorManager::class.java)
        hinge = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        hinge?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        refreshStatus()
        refreshSwitchAngle()
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
    }

    // ───────────────────────── UI ─────────────────────────

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun buildUi(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(32), dp(24), dp(48))
        }

        col.addView(TextView(this).apply {
            text = "폴드 블러"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = "접고 펼 때 외부·내부 화면이 이어지는 듯한 블러 전환"
            alpha = 0.7f
            setPadding(0, dp(4), 0, dp(16))
        })

        statusText = TextView(this).apply { setPadding(0, 0, 0, dp(12)) }
        col.addView(statusText)

        angleText = TextView(this).apply { textSize = 20f; text = "힌지 각도: --°" }
        col.addView(angleText)
        switchText = TextView(this).apply { alpha = 0.8f; setPadding(0, dp(4), 0, dp(16)) }
        col.addView(switchText)

        toggleButton = Button(this).apply { setOnClickListener { toggleService() } }
        col.addView(toggleButton)
        col.addView(Button(this).apply {
            text = "미리보기 (0° → 180° → 0°)"
            setOnClickListener { preview() }
        })
        col.addView(Button(this).apply {
            text = "기록된 전환 각도를 피크로 설정"
            setOnClickListener { usePeakFromSwitch() }
        })

        col.addView(sectionTitle("효과 세기"))
        addSlider(col, "최대 블러", Prefs.MAX_BLUR, 0, 150, "px")
        addSlider(col, "어둡게", Prefs.MAX_DIM, 0, 60, "%")

        col.addView(sectionTitle("각도 곡선"))
        addSlider(col, "시작 각도", Prefs.START_ANGLE, 0, 60, "°")
        addSlider(col, "피크 각도", Prefs.PEAK_ANGLE, 10, 170, "°")
        addSlider(col, "끝 각도", Prefs.END_ANGLE, 120, 180, "°")

        col.addView(sectionTitle("동작 방식"))
        motionSwitch = Switch(this).apply {
            text = "움직일 때만 효과 (반쯤 펴고 볼 땐 선명하게)"
            isChecked = prefs.getBoolean(Prefs.MOTION_ONLY, Prefs.DEFAULT_MOTION_ONLY)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(Prefs.MOTION_ONLY, checked).apply()
            }
            setPadding(0, dp(8), 0, dp(8))
        }
        col.addView(motionSwitch)
        addSlider(col, "멈춘 뒤 유지", Prefs.HOLD_MS, 0, 1000, "ms")

        col.addView(Button(this).apply {
            text = "기본값 복원"
            setOnClickListener { resetDefaults() }
        })

        return ScrollView(this).apply { addView(col) }
    }

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(24), 0, dp(4))
    }

    private fun addSlider(parent: LinearLayout, label: String, key: String, min: Int, max: Int, unit: String) {
        val tv = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val sb = SeekBar(this).apply {
            this.min = min
            this.max = max
            progress = Prefs.int(prefs, key)
        }
        tv.text = "$label: ${sb.progress}$unit"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                tv.text = "$label: $v$unit"
                prefs.edit().putInt(key, v).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar) = Unit
            override fun onStopTrackingTouch(s: SeekBar) = Unit
        })
        sliders[key] = sb
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun refreshStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val blurOk = getSystemService(WindowManager::class.java).isCrossWindowBlurEnabled
        val lines = mutableListOf<String>()
        lines += if (hinge != null) "✅ 힌지 센서 감지됨" else "❌ 힌지 센서 없음 (폴더블 기기 전용)"
        lines += if (overlayOk) "✅ 다른 앱 위에 표시 권한" else "⚠️ 다른 앱 위에 표시 권한 필요"
        lines += if (blurOk) "✅ 시스템 블러 사용 가능"
        else "⚠️ 시스템 블러 꺼짐 → 접근성 > 시인성 향상 > '투명도 및 흐림 효과 줄이기' 끄기, 절전 모드 해제 (지금은 어둡게만 적용)"
        statusText.text = lines.joinToString("\n")
        toggleButton.text = if (FoldBlurService.isRunning) "■ 중지" else "▶ 시작"
    }

    private fun refreshSwitchAngle() {
        val a = prefs.getFloat(Prefs.LAST_SWITCH_ANGLE, -1f)
        switchText.text = if (a < 0) "화면 전환 각도: 아직 기록 없음 (서비스 켜고 한 번 접었다 펴보세요)"
        else "마지막 외부↔내부 화면 전환 각도: ${a.roundToInt()}°"
    }

    // ───────────────────────── 동작 ─────────────────────────

    private fun toggleService() {
        if (FoldBlurService.isRunning) {
            stopService(Intent(this, FoldBlurService::class.java))
        } else {
            if (!ensurePermissions()) return
            startForegroundService(Intent(this, FoldBlurService::class.java))
        }
        handler.postDelayed({ refreshStatus() }, 300)
    }

    private fun preview() {
        if (!ensurePermissions()) return
        startForegroundService(
            Intent(this, FoldBlurService::class.java).setAction(FoldBlurService.ACTION_PREVIEW)
        )
        handler.postDelayed({ refreshStatus() }, 300)
    }

    private fun ensurePermissions(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'폴드 블러'에 다른 앱 위에 표시 권한을 허용해 주세요", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        return true
    }

    private fun usePeakFromSwitch() {
        val a = prefs.getFloat(Prefs.LAST_SWITCH_ANGLE, -1f)
        if (a < 0) {
            Toast.makeText(this, "먼저 서비스를 켠 상태로 한 번 접었다 펴주세요", Toast.LENGTH_SHORT).show()
            return
        }
        sliders[Prefs.PEAK_ANGLE]?.progress = a.roundToInt()
        Toast.makeText(this, "피크 각도를 ${a.roundToInt()}°로 설정", Toast.LENGTH_SHORT).show()
    }

    private fun resetDefaults() {
        Prefs.DEFAULTS.forEach { (k, v) -> sliders[k]?.progress = v }
        motionSwitch.isChecked = Prefs.DEFAULT_MOTION_ONLY
    }

    // ───────────────────────── 센서 ─────────────────────────

    override fun onSensorChanged(event: SensorEvent) {
        angleText.text = "힌지 각도: ${event.values[0].roundToInt()}°"
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
