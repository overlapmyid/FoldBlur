package com.kyn.foldblur

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity(), SensorEventListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var sensorManager: SensorManager
    private var hinge: Sensor? = null

    private lateinit var statusText: TextView
    private lateinit var angleText: TextView
    private lateinit var switchText: TextView
    private lateinit var toggleButton: Button
    private lateinit var motionSwitch: Switch
    private lateinit var pulseSwitch: Switch
    private lateinit var darkSwitch: Switch
    private lateinit var sensorText: TextView
    private val seenValues = sortedSetOf<Int>()
    private val sliders = mutableMapOf<String, SeekBar>()
    private val handler = Handler(Looper.getMainLooper())

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.LAST_SWITCH_ANGLE) refreshSwitchAngle()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        sensorManager = getSystemService(SensorManager::class.java)
        hinge = SensorPick.find(sensorManager, prefs.getString(Prefs.SENSOR_KEY, null))
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        hinge?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        refreshStatus()
        refreshSwitchAngle()
        refreshSensorText()
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
    }

    // ───────────────────────── UI ─────────────────────────

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun buildUi(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(32), dp(24), dp(48))
        }

        col.addView(TextView(this).apply {
            text = "폴드 블러"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = "접고 펼 때 외부·내부 화면이 이어지는 듯한 블러 전환"
            alpha = 0.7f
            setPadding(0, dp(4), 0, dp(16))
        })

        statusText = TextView(this).apply { setPadding(0, 0, 0, dp(12)) }
        col.addView(statusText)

        angleText = TextView(this).apply { textSize = 20f; text = "힌지 각도: --°" }
        col.addView(angleText)
        switchText = TextView(this).apply { alpha = 0.8f; setPadding(0, dp(4), 0, dp(8)) }
        col.addView(switchText)
        sensorText = TextView(this).apply { alpha = 0.8f; setPadding(0, 0, 0, dp(8)) }
        col.addView(sensorText)
        col.addView(Button(this).apply {
            text = "센서 선택 (각도가 단계로만 나오면 다른 센서 찾아보기)"
            setOnClickListener { pickSensor() }
        })

        toggleButton = Button(this).apply { setOnClickListener { toggleService() } }
        col.addView(toggleButton)
        col.addView(Button(this).apply {
            text = "미리보기 (0° → 180° → 0°)"
            setOnClickListener { preview() }
        })
        col.addView(Button(this).apply {
            text = "기록된 전환 각도를 피크로 설정"
            setOnClickListener { usePeakFromSwitch() }
        })

        col.addView(sectionTitle("습기 찬 유리 효과"))
        addSlider(col, "뿌연 정도", Prefs.FOG, 0, 100, "%")
        addSlider(col, "서리 입자감", Prefs.GRAIN, 0, 100, "%")
        addSlider(col, "시스템 블러 (지원 기기만)", Prefs.MAX_BLUR, 0, 150, "px")
        addSlider(col, "어둡게", Prefs.MAX_DIM, 0, 60, "%")
        darkSwitch = addSwitch(col, "어두운 안개 (다크모드용)", Prefs.DARK_FOG, Prefs.DEFAULT_DARK_FOG)

        col.addView(sectionTitle("각도 곡선"))
        addSlider(col, "시작 각도", Prefs.START_ANGLE, 0, 60, "°")
        addSlider(col, "피크 각도", Prefs.PEAK_ANGLE, 10, 170, "°")
        addSlider(col, "끝 각도", Prefs.END_ANGLE, 120, 180, "°")

        col.addView(sectionTitle("동작 방식"))
        pulseSwitch = addSwitch(col, "펄스 모드 (각도가 0/90/180처럼 단계로만 나오는 기기용)", Prefs.PULSE_MODE, Prefs.DEFAULT_PULSE_MODE)
        addSlider(col, "펄스 걷히는 시간", Prefs.PULSE_MS, 150, 1500, "ms")
        motionSwitch = addSwitch(col, "움직일 때만 효과 (펄스 모드 꺼졌을 때)", Prefs.MOTION_ONLY, Prefs.DEFAULT_MOTION_ONLY)
        addSlider(col, "멈춘 뒤 유지", Prefs.HOLD_MS, 0, 1000, "ms")

        col.addView(Button(this).apply {
            text = "기본값 복원"
            setOnClickListener { resetDefaults() }
        })

        return ScrollView(this).apply { addView(col) }
    }

    private fun addSwitch(parent: LinearLayout, label: String, key: String, def: Boolean): Switch {
        val sw = Switch(this).apply {
            text = label
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
            setPadding(0, dp(8), 0, dp(8))
        }
        parent.addView(sw)
        return sw
    }

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(24), 0, dp(4))
    }

    private fun addSlider(parent: LinearLayout, label: String, key: String, min: Int, max: Int, unit: String) {
        val tv = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val sb = SeekBar(this).apply {
            this.min = min
            this.max = max
            progress = Prefs.int(prefs, key)
        }
        tv.text = "$label: ${sb.progress}$unit"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                tv.text = "$label: $v$unit"
                prefs.edit().putInt(key, v).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar) = Unit
            override fun onStopTrackingTouch(s: SeekBar) = Unit
        })
        sliders[key] = sb
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun refreshStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val blurOk = getSystemService(WindowManager::class.java).isCrossWindowBlurEnabled
        val lines = mutableListOf<String>()
        lines += if (hinge != null) "✅ 힌지 센서 감지됨" else "❌ 힌지 센서 없음 (폴더블 기기 전용)"
        lines += if (overlayOk) "✅ 다른 앱 위에 표시 권한" else "⚠️ 다른 앱 위에 표시 권한 필요"
        lines += if (blurOk) "✅ 시스템 블러 사용 가능 (안개 + 실제 블러)"
        else "ℹ️ 시스템 블러 미지원 → 습기 찬 유리 효과로 대체 동작"
        statusText.text = lines.joinToString("\n")
        toggleButton.text = if (FoldBlurService.isRunning) "■ 중지" else "▶ 시작"
    }

    private fun refreshSwitchAngle() {
        val a = prefs.getFloat(Prefs.LAST_SWITCH_ANGLE, -1f)
        switchText.text = if (a < 0) "화면 전환 각도: 아직 기록 없음 (서비스 켜고 한 번 접었다 펴보세요)"
        else "마지막 외부↔내부 화면 전환 각도: ${a.roundToInt()}°"
    }

    // ───────────────────────── 동작 ─────────────────────────

    private fun toggleService() {
        if (FoldBlurService.isRunning) {
            stopService(Intent(this, FoldBlurService::class.java))
        } else {
            if (!ensurePermissions()) return
            startForegroundService(Intent(this, FoldBlurService::class.java))
        }
        handler.postDelayed({ refreshStatus() }, 300)
    }

    private fun preview() {
        if (!ensurePermissions()) return
        startForegroundService(
            Intent(this, FoldBlurService::class.java).setAction(FoldBlurService.ACTION_PREVIEW)
        )
        handler.postDelayed({ refreshStatus() }, 300)
    }

    private fun ensurePermissions(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'폴드 블러'에 다른 앱 위에 표시 권한을 허용해 주세요", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        return true
    }

    private fun usePeakFromSwitch() {
        val a = prefs.getFloat(Prefs.LAST_SWITCH_ANGLE, -1f)
        if (a < 0) {
            Toast.makeText(this, "먼저 서비스를 켠 상태로 한 번 접었다 펴주세요", Toast.LENGTH_SHORT).show()
            return
        }
        sliders[Prefs.PEAK_ANGLE]?.progress = a.roundToInt()
        Toast.makeText(this, "피크 각도를 ${a.roundToInt()}°로 설정", Toast.LENGTH_SHORT).show()
    }

    private fun resetDefaults() {
        Prefs.DEFAULTS.forEach { (k, v) -> sliders[k]?.progress = v }
        motionSwitch.isChecked = Prefs.DEFAULT_MOTION_ONLY
        pulseSwitch.isChecked = Prefs.DEFAULT_PULSE_MODE
        darkSwitch.isChecked = Prefs.DEFAULT_DARK_FOG
    }

    // ───────────────────────── 센서 ─────────────────────────

    override fun onSensorChanged(event: SensorEvent) {
        val v0 = event.values[0]
        if (seenValues.size < 40) seenValues += v0.roundToInt()
        val all = event.values.joinToString(", ") { "%.1f".format(it) }
        angleText.text = "센서 값: ${v0.roundToInt()}   [$all]\n받은 값 종류: ${seenValues.joinToString(" ")}"
    }

    private fun refreshSensorText() {
        sensorText.text = hinge?.let { "사용 중 센서: ${it.name} (type ${it.type})" } ?: "사용 중 센서: 없음"
    }

    private fun pickSensor() {
        val list = SensorPick.candidates(sensorManager)
        AlertDialog.Builder(this)
            .setTitle("효과에 쓸 센서 선택 (위쪽일수록 힌지 관련 가능성 높음)")
            .setItems(list.map { SensorPick.label(it) }.toTypedArray()) { _, i ->
                val s = list[i]
                prefs.edit().putString(Prefs.SENSOR_KEY, SensorPick.key(s)).apply()
                sensorManager.unregisterListener(this)
                hinge = s
                seenValues.clear()
                sensorManager.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
                refreshSensorText()
                Toast.makeText(this, "폰을 천천히 접었다 펴면서 값이 촘촘하게 변하는지 보세요", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("기본 힌지 센서로") { _, _ ->
                prefs.edit().remove(Prefs.SENSOR_KEY).apply()
                sensorManager.unregisterListener(this)
                hinge = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
                seenValues.clear()
                hinge?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
                refreshSensorText()
            }
            .show()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
