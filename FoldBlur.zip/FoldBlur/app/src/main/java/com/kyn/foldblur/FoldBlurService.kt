package com.kyn.foldblur

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.view.Choreographer
import android.view.Display
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import java.util.function.Consumer
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.roundToInt

/**
 * 힌지 각도를 실시간으로 읽어 전체 화면 오버레이 창의
 * "창 뒤 블러(blur-behind)" 반경과 투명도를 조절하는 포그라운드 서비스.
 *
 * 폴드는 접고 펼 때 논리 디스플레이 0번이 외부↔내부 패널로 바뀌기 때문에
 * 오버레이가 그대로 따라가며, 외부 화면이 흐려진 채 꺼지고 내부 화면이
 * 흐린 상태로 켜진 뒤 선명해지는 흐름으로 "이어진 느낌"을 만든다.
 */
class FoldBlurService : Service(), SensorEventListener {

    companion object {
        const val ACTION_STOP = "com.kyn.foldblur.STOP"
        const val ACTION_PREVIEW = "com.kyn.foldblur.PREVIEW"
        private const val CHANNEL_ID = "foldblur"
        private const val NOTIF_ID = 1

        /** Android 12+ 규칙: 다른 앱 오버레이는 불투명도 0.8 이하여야 터치가 통과됨 */
        private const val MAX_TOUCH_SAFE_ALPHA = 0.8f
        private const val FADE_OUT_MS = 220f
        private const val MOTION_DEG_THRESHOLD = 0.5f

        @Volatile
        var isRunning = false
            private set
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var sensorManager: SensorManager
    private lateinit var wm: WindowManager
    private var hinge: Sensor? = null
    private var overlay: View? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var choreographer: Choreographer

    private var cfg: EffectConfig? = null
    private var blurEnabled = false

    // 각도/움직임 상태
    private var realAngle = 0f
    private var angle = 0f
    private var lastAngleForMotion = Float.NaN
    private var lastMotionNanos = 0L
    private var previewing = false
    private var previewAnimator: ValueAnimator? = null

    // 애니메이션 상태
    private var current = 0f
    private var lastFrameNanos = 0L
    private var looping = false
    private var appliedRadius = -1
    private var appliedAlpha = -1f

    private var lastSmallestWidthDp = 0

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { p, _ ->
        cfg = EffectConfig.load(p)
        overlay?.setBackgroundColor(dimColor())
    }

    private val blurListener = Consumer<Boolean> { enabled ->
        blurEnabled = enabled
        appliedRadius = -1
    }

    private val frameCallback = Choreographer.FrameCallback { t -> onFrame(t) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        prefs = getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        cfg = EffectConfig.load(prefs)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)

        sensorManager = getSystemService(SensorManager::class.java)
        hinge = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
        choreographer = Choreographer.getInstance()

        startInForeground()
        addOverlay()

        blurEnabled = wm.isCrossWindowBlurEnabled
        wm.addCrossWindowBlurEnabledListener(mainExecutor, blurListener)

        hinge?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST) }
        lastSmallestWidthDp = resources.configuration.smallestScreenWidthDp
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_PREVIEW -> runPreview()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        previewAnimator?.cancel()
        sensorManager.unregisterListener(this)
        choreographer.removeFrameCallback(frameCallback)
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        runCatching { wm.removeCrossWindowBlurEnabledListener(blurListener) }
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
        super.onDestroy()
    }

    // ───────────────────────── 오버레이 ─────────────────────────

    private fun addOverlay() {
        // 오버레이 전용 WindowContext 사용 (Android 12+ 권장 방식)
        val display = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val winCtx = createWindowContext(display, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null)
        wm = winCtx.getSystemService(WindowManager::class.java)

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            alpha = 0f
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            fitInsetsTypes = 0
            title = "FoldBlurOverlay"
        }

        overlay = View(winCtx).apply { setBackgroundColor(dimColor()) }
        wm.addView(overlay, lp)
    }

    private fun dimColor(): Int {
        val dim = (cfg?.maxDim ?: 0).coerceIn(0, 100)
        return Color.argb((dim / 100f * 255).roundToInt(), 0, 0, 0)
    }

    private fun apply(intensity: Float) {
        val c = cfg ?: return
        val view = overlay ?: return
        val radius = if (blurEnabled) (c.maxBlur * intensity).roundToInt() else 0
        val alpha = (intensity * MAX_TOUCH_SAFE_ALPHA).coerceIn(0f, MAX_TOUCH_SAFE_ALPHA)

        val alphaChanged = abs(alpha - appliedAlpha) >= 0.01f || (alpha == 0f && appliedAlpha != 0f)
        if (radius == appliedRadius && !alphaChanged) return

        lp.alpha = alpha
        if (radius > 0) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = radius
        } else {
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND.inv()
            lp.blurBehindRadius = 0
        }
        runCatching { wm.updateViewLayout(view, lp) }
        appliedRadius = radius
        appliedAlpha = alpha
    }

    // ───────────────────────── 센서 ─────────────────────────

    override fun onSensorChanged(event: SensorEvent) {
        realAngle = event.values[0]
        if (!previewing) onAngle(realAngle)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun onAngle(a: Float) {
        if (lastAngleForMotion.isNaN()) {
            lastAngleForMotion = a
        } else if (abs(a - lastAngleForMotion) >= MOTION_DEG_THRESHOLD) {
            lastMotionNanos = System.nanoTime()
            lastAngleForMotion = a
        }
        angle = a
        ensureLooping()
    }

    /** 외부↔내부 화면이 바뀐 순간의 각도를 기록 → 앱에서 피크 각도로 지정 가능 */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val sw = newConfig.smallestScreenWidthDp
        if (sw != lastSmallestWidthDp) {
            lastSmallestWidthDp = sw
            if (hinge != null && !previewing) {
                prefs.edit().putFloat(Prefs.LAST_SWITCH_ANGLE, realAngle).apply()
            }
        }
    }

    // ───────────────────────── 애니메이션 루프 ─────────────────────────

    private fun motionFactor(nowNanos: Long): Float {
        val c = cfg ?: return 0f
        if (!c.motionOnly) return 1f
        val sinceMs = (nowNanos - lastMotionNanos) / 1_000_000f
        return when {
            sinceMs <= c.holdMs -> 1f
            sinceMs >= c.holdMs + FADE_OUT_MS -> 0f
            else -> 1f - (sinceMs - c.holdMs) / FADE_OUT_MS
        }
    }

    private fun ensureLooping() {
        if (looping) return
        looping = true
        lastFrameNanos = 0L
        choreographer.postFrameCallback(frameCallback)
    }

    private fun onFrame(frameNanos: Long) {
        val c = cfg ?: return
        val now = System.nanoTime()
        val dt = if (lastFrameNanos == 0L) 0.016f
        else ((frameNanos - lastFrameNanos) / 1e9f).coerceIn(0f, 0.1f)
        lastFrameNanos = frameNanos

        val target = c.curve(angle) * motionFactor(now)
        // 들어갈 땐 빠르게, 빠질 땐 조금 느리게
        val tau = if (target > current) 0.035f else 0.09f
        current += (target - current) * (1f - exp(-dt / tau))
        if (abs(target - current) < 0.002f) current = target

        apply(current)

        val motionFading = c.motionOnly &&
            (now - lastMotionNanos) / 1_000_000f < c.holdMs + FADE_OUT_MS
        if (current != target || motionFading || previewing) {
            choreographer.postFrameCallback(frameCallback)
        } else {
            looping = false
        }
    }

    // ───────────────────────── 미리보기 ─────────────────────────

    /** 폰을 접지 않고도 0°→180°→0° 가상 스윕으로 효과 확인 */
    private fun runPreview() {
        previewAnimator?.cancel()
        previewing = true
        previewAnimator = ValueAnimator.ofFloat(0f, 180f).apply {
            duration = 1200
            repeatCount = 1
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { onAngle(it.animatedValue as Float) }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    previewing = false
                    onAngle(realAngle)
                }
            })
            start()
        }
    }

    // ───────────────────────── 알림 ─────────────────────────

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "폴드 블러 실행 중", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, FoldBlurService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val openPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        val text = if (hinge == null) "힌지 센서를 찾지 못했습니다" else "접거나 펼치면 블러 전환 효과가 적용됩니다"
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("폴드 블러 동작 중")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat), "중지", stopPi
                ).build()
            )
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }
}
