package com.kyn.foldblur

import android.content.SharedPreferences
import android.hardware.Sensor
import android.hardware.SensorManager

/** 설정 키와 기본값 */
object Prefs {
    const val NAME = "foldblur"

    const val MAX_BLUR = "max_blur"          // px, 시스템 창 뒤 블러 (기기가 지원할 때만)
    const val FOG = "fog"                    // %, 습기 찬 유리 느낌의 뿌연 막 농도
    const val GRAIN = "grain"                // %, 서리 유리 입자감
    const val MAX_DIM = "max_dim"            // %, 어둡게
    const val DARK_FOG = "dark_fog"          // 안개를 어두운 톤으로
    const val START_ANGLE = "start_angle"
    const val PEAK_ANGLE = "peak_angle"
    const val END_ANGLE = "end_angle"
    const val MOTION_ONLY = "motion_only"
    const val HOLD_MS = "hold_ms"
    const val PULSE_MODE = "pulse_mode"      // 각도가 0/90/180 단계로만 나오는 기기용
    const val PULSE_MS = "pulse_ms"          // 펄스가 풀리는 시간
    const val SENSOR_KEY = "sensor_key"      // 효과에 쓸 센서 ("type|name")
    const val LAST_SWITCH_ANGLE = "last_switch_angle"

    val DEFAULTS = mapOf(
        MAX_BLUR to 90,
        FOG to 70,
        GRAIN to 35,
        MAX_DIM to 0,
        START_ANGLE to 3,
        PEAK_ANGLE to 90,
        END_ANGLE to 175,
        HOLD_MS to 180,
        PULSE_MS to 550,
    )
    const val DEFAULT_MOTION_ONLY = true
    const val DEFAULT_PULSE_MODE = true
    const val DEFAULT_DARK_FOG = false

    fun int(p: SharedPreferences, key: String): Int = p.getInt(key, DEFAULTS.getValue(key))
}

/** 효과에 사용할 센서 선택/검색 */
object SensorPick {
    fun key(s: Sensor) = "${s.type}|${s.name}"

    fun find(sm: SensorManager, key: String?): Sensor? {
        if (!key.isNullOrEmpty()) {
            sm.getSensorList(Sensor.TYPE_ALL).firstOrNull { key(it) == key }?.let { return it }
        }
        return sm.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
    }

    private val HINTS = listOf("hinge", "angle", "fold", "posture", "hall", "flip", "cover")

    /** 힌지 관련 가능성이 높은 센서를 앞쪽으로 정렬한 전체 목록 */
    fun candidates(sm: SensorManager): List<Sensor> =
        sm.getSensorList(Sensor.TYPE_ALL).sortedBy { s ->
            val n = (s.name + " " + s.stringType).lowercase()
            when {
                s.type == Sensor.TYPE_HINGE_ANGLE -> 0
                HINTS.any { it in n } -> 1
                s.type >= Sensor.TYPE_DEVICE_PRIVATE_BASE -> 2
                else -> 3
            }
        }

    fun label(s: Sensor): String =
        "${s.name}\n  type ${s.type} · ${s.stringType} · ${s.vendor}"
}

data class EffectConfig(
    val maxBlur: Int,
    val fog: Int,
    val grain: Int,
    val maxDim: Int,
    val darkFog: Boolean,
    val startAngle: Int,
    val peakAngle: Int,
    val endAngle: Int,
    val motionOnly: Boolean,
    val holdMs: Int,
    val pulseMode: Boolean,
    val pulseMs: Int,
) {
    /** 힌지 각도 → 효과 강도(0~1). 비대칭 smoothstep 종 모양 */
    fun curve(angle: Float): Float {
        val s = startAngle.toFloat()
        val e = endAngle.toFloat()
        if (e - s < 4f || angle <= s || angle >= e) return 0f
        val p = peakAngle.toFloat().coerceIn(s + 1f, e - 1f)
        val t = if (angle < p) (angle - s) / (p - s) else (e - angle) / (e - p)
        val c = t.coerceIn(0f, 1f)
        return c * c * (3f - 2f * c)
    }

    /** 펄스 모드: 이벤트 후 경과 시간 → 강도 (빠르게 뿌옇게 → 천천히 걷힘) */
    fun pulse(sinceMs: Float): Float {
        val rise = 90f
        val hold = 80f
        return when {
            sinceMs < 0f -> 0f
            sinceMs < rise -> smooth(sinceMs / rise)
            sinceMs < rise + hold -> 1f
            sinceMs < rise + hold + pulseMs -> 1f - smooth((sinceMs - rise - hold) / pulseMs)
            else -> 0f
        }
    }

    fun pulseTotalMs() = 90f + 80f + pulseMs

    private fun smooth(t: Float): Float {
        val c = t.coerceIn(0f, 1f)
        return c * c * (3f - 2f * c)
    }

    companion object {
        fun load(p: SharedPreferences) = EffectConfig(
            maxBlur = Prefs.int(p, Prefs.MAX_BLUR),
            fog = Prefs.int(p, Prefs.FOG),
            grain = Prefs.int(p, Prefs.GRAIN),
            maxDim = Prefs.int(p, Prefs.MAX_DIM),
            darkFog = p.getBoolean(Prefs.DARK_FOG, Prefs.DEFAULT_DARK_FOG),
            startAngle = Prefs.int(p, Prefs.START_ANGLE),
            peakAngle = Prefs.int(p, Prefs.PEAK_ANGLE),
            endAngle = Prefs.int(p, Prefs.END_ANGLE),
            motionOnly = p.getBoolean(Prefs.MOTION_ONLY, Prefs.DEFAULT_MOTION_ONLY),
            holdMs = Prefs.int(p, Prefs.HOLD_MS),
            pulseMode = p.getBoolean(Prefs.PULSE_MODE, Prefs.DEFAULT_PULSE_MODE),
            pulseMs = Prefs.int(p, Prefs.PULSE_MS),
        )
    }
}
