package com.kyn.foldblur

import android.content.SharedPreferences

/** 설정 키와 기본값 */
object Prefs {
    const val NAME = "foldblur"

    const val MAX_BLUR = "max_blur"          // px, 창 뒤 블러 최대 반경
    const val MAX_DIM = "max_dim"            // %, 블러와 함께 깔리는 어둡게 효과
    const val START_ANGLE = "start_angle"    // 이 각도부터 효과 시작
    const val PEAK_ANGLE = "peak_angle"      // 효과 최대 지점 (화면 전환 각도에 맞추면 좋음)
    const val END_ANGLE = "end_angle"        // 이 각도부터 완전히 선명
    const val MOTION_ONLY = "motion_only"    // 힌지가 움직일 때만 효과
    const val HOLD_MS = "hold_ms"            // 움직임 멈춘 뒤 효과 유지 시간
    const val LAST_SWITCH_ANGLE = "last_switch_angle" // 서비스가 기록한 외부↔내부 전환 각도

    val DEFAULTS = mapOf(
        MAX_BLUR to 90,
        MAX_DIM to 20,
        START_ANGLE to 3,
        PEAK_ANGLE to 90,
        END_ANGLE to 175,
        HOLD_MS to 180,
    )
    const val DEFAULT_MOTION_ONLY = true

    fun int(p: SharedPreferences, key: String): Int = p.getInt(key, DEFAULTS.getValue(key))
}

data class EffectConfig(
    val maxBlur: Int,
    val maxDim: Int,
    val startAngle: Int,
    val peakAngle: Int,
    val endAngle: Int,
    val motionOnly: Boolean,
    val holdMs: Int,
) {
    /**
     * 힌지 각도 → 효과 강도(0~1).
     * 시작~피크까지 부드럽게 올라가고 피크~끝까지 내려가는 비대칭 종 모양 곡선.
     */
    fun curve(angle: Float): Float {
        val s = startAngle.toFloat()
        val e = endAngle.toFloat()
        if (e - s < 4f || angle <= s || angle >= e) return 0f
        val p = peakAngle.toFloat().coerceIn(s + 1f, e - 1f)
        val t = if (angle < p) (angle - s) / (p - s) else (e - angle) / (e - p)
        val c = t.coerceIn(0f, 1f)
        return c * c * (3f - 2f * c) // smoothstep
    }

    companion object {
        fun load(p: SharedPreferences) = EffectConfig(
            maxBlur = Prefs.int(p, Prefs.MAX_BLUR),
            maxDim = Prefs.int(p, Prefs.MAX_DIM),
            startAngle = Prefs.int(p, Prefs.START_ANGLE),
            peakAngle = Prefs.int(p, Prefs.PEAK_ANGLE),
            endAngle = Prefs.int(p, Prefs.END_ANGLE),
            motionOnly = p.getBoolean(Prefs.MOTION_ONLY, Prefs.DEFAULT_MOTION_ONLY),
            holdMs = Prefs.int(p, Prefs.HOLD_MS),
        )
    }
}
